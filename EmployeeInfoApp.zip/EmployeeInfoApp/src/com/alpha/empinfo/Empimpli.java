package com.alpha.empinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;

public class Empimpli implements Empinter{

	@Override
	public void createEmp(EmpInfo emp) {
		Connection con= DataBasecon.createDataBasecon();
		String query="insert into employee values(?,?,?,?)";
	    
		try {
			PreparedStatement p=con.prepareStatement(query);
			p.setInt(1, emp.getId());
			p.setString(1, emp.getName());
			p.setInt(3, emp.getAge());
			p.setDouble(4, emp.getSal());
			int c=p.executeUpdate();
			if(c!=0) {
				System.out.println(" data inserted");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void showEmp() {
		Connection con=DataBasecon.createDataBasecon();
		String query="select * from employee"; 
		
		try {
			Statement st=con.createStatement();
			 ResultSet res= st.executeQuery(query);
		     while(res.next())
		    	 System.out.format("%d", res.getInt(1), res.getString(2), res.getInt(3), res.getDouble(4));
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void showEmpByid(int id) {
		Connection con=DataBasecon.createDataBasecon();
		String query="select * from employee where empid="+id;
		try {
			Statement st=con.createStatement();
			 ResultSet res= st.executeQuery(query);
			 while(res.next())
		    	 System.out.format("%d", res.getInt(1), res.getString(2), res.getInt(3), res.getDouble(4));
		
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateEmpInfo(int id, String name) {
		Connection con=DataBasecon.createDataBasecon();
		String query="update employee set name=? where id=?";
		try {
			PreparedStatement p=con.prepareStatement(query);
			p.setInt(1, id);
			p.setString(2, name);
			p.executeUpdate();
			System.out.println("updated");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmp(int id) {
		Connection con=DataBasecon.createDataBasecon();
		String query="delete from employee where id=?";
		try {
			PreparedStatement p=con.prepareStatement(query);
			p.setInt(1, id);
			p.executeUpdate();
			
			System.out.println("deleted successfuly");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

}
