package com.alpha.empinfo;

public interface Empinter  {

	public void createEmp(EmpInfo emp);
	
	public void showEmp();
	
	public void showEmpByid(int id);
	
	public void updateEmpInfo(int id, String name);
	
	public void deleteEmp(int id);
	
}
