package com.alpha.empinfo;

import java.util.Scanner;

public class Main {

	 public static void main(String[] args) {
		 
		 String name;
		 int id;
		 Empinter e=new Empimpli();
		 
		 System.out.println("Hello dear user Wellcome");
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("select below options to continue\n"+"1. add employee\n"+"2. show employees\n"+
		 "3. show employee by id\n"+"4. update employee\n"+"5. delete employee");
		 
		 System.out.println("enter choice");
		 int ch=sc.nextInt();
		 switch(ch) {
		 
		 case 1:
			 EmpInfo emp=new EmpInfo();
			 System.out.println("enter id");
			  id=sc.nextInt();
			 System.out.println("enter name");
			  name=sc.next();
			 System.out.println("enter age age");
			 int age=sc.nextInt();
			 System.out.println("enter salary");
			 double sal=sc.nextDouble();
			 emp.setId(id);
			 emp.setName(name);
			 emp.setAge(age);
			 emp.setSal(sal);
			 
			 e.createEmp(emp);
		 break;
		 
		 case 2: e.showEmp();
		 break;
		 
		 case 3: 
			 System.out.println("enter emp id");
			 Scanner scc=new Scanner(System.in);
			 int empid=scc.nextInt();
			 e.showEmpByid(empid);
			 break;
			 
		 case 4:
			 System.out.println("enter id to update");
			 int empid1=sc.nextInt();
			 System.out.println("enter name to update");
			 name=sc.next();
			
			e.updateEmpInfo(empid1, name);
			break;
			
		 case 5: 
			 System.out.println("enter id to delete");
			 id=sc.nextInt();
			 e.deleteEmp(id);
			 break;
		 default : System.out.println( "enter valid choice");
		 break;
		 case 6: System.out.println("thankyou 🙌");
		 System.exit(0);
		 }
	}
}
